import 'package:bilim_hesap/math/evaluator.dart';
import 'package:bilim_hesap/math/formatter.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Dort islem ve oncelik', () {
    test('carpma toplamadan once', () {
      expect(Evaluator.evaluate('2+3×4'), 14);
    });
    test('parantez', () {
      expect(Evaluator.evaluate('(2+3)×4'), 20);
    });
    test('bolme', () {
      expect(Evaluator.evaluate('10÷4'), 2.5);
    });
    test('sifira bolme hata verir', () {
      expect(() => Evaluator.evaluate('1÷0'), throwsA(isA<EvalException>()));
    });
  });

  group('Kuvvet ve tekli operatorler', () {
    test('sag birlesme', () {
      expect(Evaluator.evaluate('2^3^2'), 512);
    });
    test('tekli eksi kuvvetten sonra gelir', () {
      expect(Evaluator.evaluate('-2^2'), -4);
    });
    test('negatif ustel', () {
      expect(Evaluator.evaluate('2^-2'), 0.25);
    });
  });

  group('Bilimsel fonksiyonlar', () {
    test('derece modunda sin(30)', () {
      expect(Evaluator.evaluate('sin(30)', mode: AngleMode.deg), closeTo(0.5, 1e-12));
    });
    test('radyan modunda sin(pi)', () {
      expect(Evaluator.evaluate('sin(π)', mode: AngleMode.rad), 0);
    });
    test('ln(e) = 1', () {
      expect(Evaluator.evaluate('ln(e)'), closeTo(1, 1e-12));
    });
    test('log(1000) = 3', () {
      expect(Evaluator.evaluate('log(1000)'), closeTo(3, 1e-12));
    });
    test('karekok', () {
      expect(Evaluator.evaluate('sqrt(144)'), 12);
    });
    test('kupkok negatif', () {
      expect(Evaluator.evaluate('cbrt(-27)'), closeTo(-3, 1e-12));
    });
  });

  group('Son ek operatorler ve kapali carpim', () {
    test('faktoriyel', () {
      expect(Evaluator.evaluate('5!'), 120);
    });
    test('yuzde', () {
      expect(Evaluator.evaluate('200×15%'), 30);
    });
    test('kapali carpim', () {
      expect(Evaluator.evaluate('2(3+1)'), 8);
    });
    test('mod', () {
      expect(Evaluator.evaluate('10mod3'), 1);
    });
  });

  group('Bicimlendirme', () {
    test('kayan nokta artigi temizlenir', () {
      expect(NumberFormatter.format(0.1 + 0.2), '0.3');
    });
    test('binlik ayirici', () {
      expect(NumberFormatter.format(1234567), '1 234 567');
    });
    test('cok buyuk sayi bilimsel gosterim', () {
      expect(NumberFormatter.format(1e15).contains('E'), isTrue);
    });
  });
}

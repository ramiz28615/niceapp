import 'package:bilim_hesap/main.dart';
import 'package:bilim_hesap/services/history_repository.dart';
import 'package:bilim_hesap/state/calculator_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  testWidgets('Tuslara basip hesap yapabilir', (tester) async {
    final controller = CalculatorController(HistoryRepository());
    await controller.load();

    await tester.pumpWidget(BilimHesapApp(controller: controller));
    await tester.pumpAndSettle();

    await tester.tap(find.text('7'));
    await tester.tap(find.text('×'));
    await tester.tap(find.text('8'));
    await tester.pump();

    expect(controller.expression, '7×8');
    expect(controller.preview, '56');

    await tester.tap(find.text('='));
    await tester.pumpAndSettle();

    expect(controller.justEvaluated, isTrue);
    expect(controller.history.first.result, '56');
    expect(find.byType(MaterialApp), findsOneWidget);
  });

  testWidgets('AC ekrani temizler', (tester) async {
    final controller = CalculatorController(HistoryRepository());
    await controller.load();

    await tester.pumpWidget(BilimHesapApp(controller: controller));
    await tester.pumpAndSettle();

    await tester.tap(find.text('9'));
    await tester.pump();
    expect(controller.expression, '9');

    await tester.tap(find.text('AC'));
    await tester.pump();
    expect(controller.expression, isEmpty);
  });
}

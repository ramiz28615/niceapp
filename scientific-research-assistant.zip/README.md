# BilimHesap — Bilimsel Hesap Makinesi (Flutter / Android)

Hizli, bilimsel ve **kalici gecmis** kaydi olan Android hesap makinesi.
APK, **GitHub Actions** ile otomatik derlenir — bilgisayarina Android Studio kurmana gerek yok.

---

## 1. Ozellikler

| Alan | Detay |
|---|---|
| Motor | Kendi yazdigim **Shunting-yard** ifade yorumlayici (harici matematik paketi yok) |
| Islemler | `+ − × ÷`, kuvvet `^` (sag birlesmeli), `mod`, faktoriyel `n!`, yuzde `%` |
| Fonksiyonlar | `sin cos tan`, `sin⁻¹ cos⁻¹ tan⁻¹`, `sinh cosh tanh`, `ln log log₂`, `√ ∛`, `eˣ 10ˣ x² x³`, `abs` |
| Sabitler | `π`, `e` |
| Aci modu | **DEG / RAD** anında degistirilebilir |
| Canli sonuc | Her tusa basildiginda sonuc anlik olarak `= ...` seklinde gosterilir |
| Kapali carpim | `2(3+1)`, `2π`, `3sin(30)` gibi yazimlar desteklenir |
| Hafiza | `MC / MR / M+ / M−` ve `ANS` (son sonuc) |
| Gecmis | Cihazda **kalici** saklanir (SharedPreferences), 300 kayit, silinebilir |
| Hizli erisim | Ekran altindaki seritte son 4 sonuc tek dokunusla eklenir |
| Jestler | Ekrani **asagi kaydir** → gecmis acilir · gecmis satirini **sola kaydir** → sil · sonuca **uzun bas** → kopyala |
| Hata yonetimi | "Sifira bolme", "ln tanim disi", "Parantez hatasi" gibi net Turkce mesajlar |
| Performans | `ChangeNotifier` + `ListenableBuilder`, sadece degisen parca yeniden cizilir; titresimli dokunma geri bildirimi |

---

## 2. Proje yapisi

```
.
├── .github/workflows/build-apk.yml   # APK derleyen GitHub Actions is akisi
├── lib/
│   ├── main.dart                     # Uygulama girisi
│   ├── core/app_theme.dart           # Renk paleti + tema
│   ├── math/
│   │   ├── evaluator.dart            # Ifade yorumlayici (tokenizer + RPN)
│   │   └── formatter.dart            # Sonuc bicimlendirme
│   ├── models/history_entry.dart     # Gecmis kayit modeli
│   ├── services/history_repository.dart  # Kalici depolama
│   ├── state/calculator_controller.dart  # Tum uygulama durumu
│   ├── screens/calculator_screen.dart    # Ana ekran
│   └── widgets/
│       ├── display_panel.dart        # Ust ekran
│       ├── keypad.dart               # Tus takimi
│       ├── calc_button.dart          # Tek tus
│       └── history_sheet.dart        # Gecmis alt sayfasi
├── test/                             # Birim + widget testleri
├── pubspec.yaml
└── analysis_options.yaml
```

> **Not:** `android/` klasoru depoda **yok**. GitHub Actions derleme sirasinda
> `flutter create` ile guncel Android iskeletini (Gradle, AGP, Kotlin dahil)
> kendisi uretir. Bu, "eski Gradle surumu" kaynakli derleme hatalarini onler.

---

## 3. KURULUM — GitHub Actions ile APK alma (onerilen)

Bilgisayarina hicbir sey kurmadan APK alabilirsin.

### Adim 1 — Yeni GitHub deposu olustur
1. https://github.com/new adresine git.
2. **Repository name:** `bilim-hesap` yaz.
3. **Public** veya **Private** sec (ikisi de calisir).
4. `README`, `.gitignore`, `license` eklemelerini **isaretleme** (bos depo olsun).
5. **Create repository** butonuna bas.

### Adim 2 — Dosyalari yukle

**Yol A — Tarayicidan (en kolay, terminal gerekmez):**
1. Sana verdigim ZIP dosyasini bilgisayarinda ac (cikart).
2. Yeni depo sayfasinda **uploading an existing file** baglantisina tikla.
3. Cikardigin klasorun **icindeki** tum dosya ve klasorleri surukle-birak.
   - **Onemli:** `.github` klasorunu da yuklediginden emin ol. Bazi tarayicilarda
     nokta ile baslayan klasorler surukleyince gelmez. Gelmezse Adim 3'e bak.
4. Alttaki **Commit changes** butonuna bas.

**Yol B — Git ile (terminal):**
```bash
cd bilim-hesap                 # ZIP'i cikardigin klasor
git init
git add .
git commit -m "BilimHesap ilk surum"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/bilim-hesap.git
git push -u origin main
```

### Adim 3 — `.github` klasoru yuklenmediyse (elle olusturma)
1. Depo sayfasinda **Add file → Create new file**.
2. Dosya adi kutusuna tam olarak sunu yaz:
   ```
   .github/workflows/build-apk.yml
   ```
   (`/` yazdiginda GitHub otomatik klasor olusturur)
3. ZIP icindeki `.github/workflows/build-apk.yml` dosyasinin **tum icerigini**
   kopyalayip buraya yapistir.
4. **Commit changes**.

### Adim 4 — Derlemeyi baslat
Push yaptigin an is akisi otomatik baslar. Elle baslatmak icin:
1. Deponun **Actions** sekmesine gec.
2. Soldan **Android APK Derle** is akisini sec.
3. Sagdaki **Run workflow → Run workflow** butonuna bas.

> Actions ilk kez kullaniliyorsa **"I understand my workflows, go ahead and enable them"**
> butonuna basman gerekebilir.

### Adim 5 — APK'yi indir
1. **Actions** sekmesinde calisan iси tikla (yesil tik olmasini bekle, ~5-10 dk).
2. Sayfanin en altinda **Artifacts** bolumu var.
3. **BilimHesap-APK** dosyasini indir (ZIP olarak iner).
4. ZIP'i ac. Icinde su dosyalar olur:
   - `BilimHesap-universal.apk` → **her telefonda calisir**, bunu kullan.
   - `BilimHesap-arm64-v8a.apk` → modern telefonlar icin, daha kucuk boyut.
   - `BilimHesap-armeabi-v7a.apk` → eski 32-bit telefonlar.
   - `BilimHesap-x86_64.apk` → emulator.

### Adim 6 — Telefona kur
1. APK'yi telefonuna aktar (USB, Drive, WhatsApp, e-posta...).
2. Dosyaya dokun.
3. **"Bilinmeyen kaynaklardan yuklemeye izin ver"** uyarisi cikarsa izin ver
   (Ayarlar → Uygulamalar → Ozel uygulama erisimi → Bilinmeyen uygulamalar yukle).
4. **Yukle** → **Ac**.

> Bu APK **debug imzasi** ile imzalidir; kisisel kullanim ve test icin sorunsuzdur.
> Google Play'e yuklemek istersen Bolum 6'daki imzalama adimlarini uygula.

---

## 4. Otomatik surum (Release) olusturma — istege bagli

`v` ile baslayan bir etiket atarsan APK'lar otomatik olarak
**Releases** sayfasina yuklenir ve herkes dogrudan indirebilir:

```bash
git tag v1.0.0
git push origin v1.0.0
```

---

## 5. Yerel derleme (bilgisayarinda) — istege bagli

Gerekli: Flutter SDK 3.4+, Java 17, Android SDK.

```bash
flutter --version          # Flutter kurulu mu?
flutter doctor             # Eksikleri gosterir

flutter create --project-name bilim_hesap --org com.bilimhesap --platforms=android --no-pub .
flutter pub get
flutter test               # Testler
flutter run                # Telefon/emulatorde canli calistir
flutter build apk --release            # APK uret
flutter build apk --release --split-per-abi   # Kucuk APK'lar
```

Cikti: `build/app/outputs/flutter-apk/app-release.apk`

---

## 6. Kendi imzanla derleme (Google Play icin) — istege bagli

**1. Anahtar olustur (bilgisayarinda, bir kez):**
```bash
keytool -genkey -v -keystore bilimhesap.jks -keyalg RSA \
  -keysize 2048 -validity 10000 -alias bilimhesap
```

**2. Base64'e cevir:**
```bash
base64 -w 0 bilimhesap.jks > keystore.b64   # Linux
base64 -i bilimhesap.jks | tr -d '\n' > keystore.b64   # macOS
```

**3. GitHub'a gizli anahtar olarak ekle:**
Depo → **Settings → Secrets and variables → Actions → New repository secret**

| Secret adi | Deger |
|---|---|
| `KEYSTORE_BASE64` | `keystore.b64` dosyasinin icerigi |
| `KEYSTORE_PASSWORD` | keystore sifresi |
| `KEY_PASSWORD` | anahtar sifresi |
| `KEY_ALIAS` | `bilimhesap` |

**4. `.github/workflows/build-apk.yml` icinde "Paketleri indir" adiminin
oncesine su adimi ekle:**
```yaml
      - name: Imza dosyasini hazirla
        if: ${{ secrets.KEYSTORE_BASE64 != '' }}
        run: |
          echo "${{ secrets.KEYSTORE_BASE64 }}" | base64 -d > android/app/bilimhesap.jks
          cat > android/key.properties <<EOF
          storePassword=${{ secrets.KEYSTORE_PASSWORD }}
          keyPassword=${{ secrets.KEY_PASSWORD }}
          keyAlias=${{ secrets.KEY_ALIAS }}
          storeFile=bilimhesap.jks
          EOF
```
Ayrica `android/app/build.gradle.kts` icine `signingConfigs` blogu eklemen gerekir
(Flutter resmi dokumani: https://docs.flutter.dev/deployment/android#signing-the-app).

---

## 7. Sik gorulen sorunlar

| Sorun | Cozum |
|---|---|
| Actions sekmesi bos | Depo → Actions → "Enable workflows" butonuna bas |
| `.github` yuklenmedi | Bolum 3 / Adim 3'teki elle olusturma yontemini uygula |
| Derleme "Gradle" hatasi verdi | Actions'ta **Re-run all jobs**; iskelet her seferinde yeniden uretilir |
| Artifact gorunmuyor | Is akisi bitmeden gorunmez; yesil tiki bekle |
| Telefon "uygulama yuklenemedi" diyor | `universal` APK'yi kullan; eski APK'yi kaldirip tekrar dene |
| Testler kirmizi kaldi | `flutter test` cikisini oku; is akisi testte durur (bilinçli) |

---

## 8. Klavye kisayollari (kullanim ipuclari)

- Ekrani **asagi dogru kaydir** → Gecmis acilir
- Gecmis satirina **dokun** → ifadeyi ekrana getirir
- Gecmis satirindaki **↵** → sadece sonucu ekrana getirir
- Gecmis satirini **sola kaydir** → o kaydi siler
- Sonuca **uzun bas** → panoya kopyalar
- **⌫** tusuna **uzun bas** → hepsini temizler (AC)
- **2nd** → ikincil fonksiyonlar (ters trigonometri, hiperbolik, ∛, 10ˣ, eˣ)
- **DEG/RAD** yazisina dokun → aci modu degisir

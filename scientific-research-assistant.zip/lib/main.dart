import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/app_theme.dart';
import 'screens/calculator_screen.dart';
import 'services/history_repository.dart';
import 'state/calculator_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Sistem cubuklarini uygulama temasina uyarla.
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColors.background,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  final controller = CalculatorController(HistoryRepository());
  await controller.load();

  runApp(BilimHesapApp(controller: controller));
}

class BilimHesapApp extends StatelessWidget {
  const BilimHesapApp({super.key, required this.controller});

  final CalculatorController controller;

  @override
  Widget build(BuildContext context) {
    return CalculatorScope(
      controller: controller,
      child: MaterialApp(
        title: 'BilimHesap',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark(),
        home: CalculatorScreen(controller: controller),
        builder: (context, child) {
          // Yazi boyutu asiri buyudugunde duzen bozulmasin.
          final scale = MediaQuery.textScalerOf(context).clamp(
            minScaleFactor: 0.9,
            maxScaleFactor: 1.15,
          );
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(textScaler: scale),
            child: child ?? const SizedBox.shrink(),
          );
        },
      ),
    );
  }
}

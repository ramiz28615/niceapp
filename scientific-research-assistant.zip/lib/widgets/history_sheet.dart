import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_theme.dart';
import '../models/history_entry.dart';
import '../state/calculator_controller.dart';

/// Gecmis listesi. Alt sayfadan acilir, kalicidir (cihazda saklanir).
class HistorySheet extends StatelessWidget {
  const HistorySheet({super.key, required this.controller});

  final CalculatorController controller;

  static Future<void> show(BuildContext context, CalculatorController controller) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SizedBox(
        height: MediaQuery.of(sheetContext).size.height * 0.78,
        child: HistorySheet(controller: controller),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        final items = controller.history;
        return SafeArea(
          top: false,
          child: Column(
            children: [
              const SizedBox(height: 10),
              Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.muted.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 12, 8),
                child: Row(
                  children: [
                    const Text(
                      'Gecmis',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: AppColors.foreground,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${items.length} kayit',
                      style: const TextStyle(fontSize: 13, color: AppColors.muted),
                    ),
                    const Spacer(),
                    if (items.isNotEmpty)
                      TextButton.icon(
                        onPressed: () async {
                          HapticFeedback.mediumImpact();
                          await controller.clearHistory();
                        },
                        icon: const Icon(Icons.delete_sweep_outlined,
                            size: 18, color: AppColors.danger),
                        label: const Text(
                          'Tumunu sil',
                          style: TextStyle(color: AppColors.danger),
                        ),
                      ),
                  ],
                ),
              ),
              const Divider(height: 1, color: AppColors.surfaceAlt),
              Expanded(
                child: items.isEmpty
                    ? const _EmptyHistory()
                    : ListView.separated(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        itemCount: items.length,
                        separatorBuilder: (_, __) =>
                            const Divider(height: 1, color: AppColors.surfaceAlt),
                        itemBuilder: (context, index) => _HistoryTile(
                          entry: items[index],
                          onUseExpression: () {
                            controller.useHistory(items[index]);
                            Navigator.of(context).pop();
                          },
                          onUseResult: () {
                            controller.useHistory(items[index], useResult: true);
                            Navigator.of(context).pop();
                          },
                          onDelete: () => controller.deleteHistoryAt(index),
                        ),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _HistoryTile extends StatelessWidget {
  const _HistoryTile({
    required this.entry,
    required this.onUseExpression,
    required this.onUseResult,
    required this.onDelete,
  });

  final HistoryEntry entry;
  final VoidCallback onUseExpression;
  final VoidCallback onUseResult;
  final VoidCallback onDelete;

  String get _time {
    final d = entry.createdAt;
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(d.day)}.${two(d.month)}.${d.year} ${two(d.hour)}:${two(d.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: ValueKey('${entry.createdAt.microsecondsSinceEpoch}-${entry.expression}'),
      direction: DismissDirection.endToStart,
      background: Container(
        color: AppColors.danger.withValues(alpha: 0.18),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Icon(Icons.delete_outline, color: AppColors.danger),
      ),
      onDismissed: (_) => onDelete(),
      child: InkWell(
        onTap: onUseExpression,
        onLongPress: () {
          Clipboard.setData(ClipboardData(text: entry.result));
          HapticFeedback.mediumImpact();
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      entry.expression,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, color: AppColors.muted),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '= ${entry.result}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: AppColors.foreground,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$_time  ·  ${entry.angleMode}',
                      style: const TextStyle(fontSize: 11, color: AppColors.muted),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Sonucu kullan',
                onPressed: onUseResult,
                icon: const Icon(Icons.subdirectory_arrow_left,
                    color: AppColors.accent, size: 20),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyHistory extends StatelessWidget {
  const _EmptyHistory();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.calculate_outlined, size: 44, color: AppColors.muted),
          SizedBox(height: 12),
          Text(
            'Henuz kayit yok',
            style: TextStyle(color: AppColors.foreground, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 4),
          Text(
            'Hesapladiginiz her islem burada saklanir.',
            style: TextStyle(color: AppColors.muted, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

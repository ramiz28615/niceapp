import 'package:flutter/material.dart';

import '../state/calculator_controller.dart';
import 'calc_button.dart';

/// 5 kolonluk bilimsel tus takimi. 2nd tusu ile fonksiyonlar degisir.
class Keypad extends StatelessWidget {
  const Keypad({super.key, required this.controller});

  final CalculatorController controller;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final second = c.second;

    final rows = <List<Widget>>[
      // Satir 1: hafiza
      [
        CalcButton(
          label: 'MC',
          styleType: CalcButtonStyleType.function,
          onTap: c.memoryClear,
        ),
        CalcButton(
          label: 'MR',
          styleType: CalcButtonStyleType.function,
          onTap: c.memoryRecall,
        ),
        CalcButton(
          label: 'M+',
          styleType: CalcButtonStyleType.function,
          onTap: c.memoryAdd,
        ),
        CalcButton(
          label: 'M-',
          styleType: CalcButtonStyleType.function,
          onTap: c.memorySubtract,
        ),
        CalcButton(
          label: 'ANS',
          styleType: CalcButtonStyleType.function,
          onTap: c.insertAnswer,
        ),
      ],
      // Satir 2: trigonometri
      [
        CalcButton(
          label: second ? 'sin⁻¹' : 'sin',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert(second ? 'asin(' : 'sin(', InsertKind.openFunc),
        ),
        CalcButton(
          label: second ? 'cos⁻¹' : 'cos',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert(second ? 'acos(' : 'cos(', InsertKind.openFunc),
        ),
        CalcButton(
          label: second ? 'tan⁻¹' : 'tan',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert(second ? 'atan(' : 'tan(', InsertKind.openFunc),
        ),
        CalcButton(
          label: second ? 'sinh' : 'ln',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert(second ? 'sinh(' : 'ln(', InsertKind.openFunc),
        ),
        CalcButton(
          label: second ? 'cosh' : 'log',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert(second ? 'cosh(' : 'log(', InsertKind.openFunc),
        ),
      ],
      // Satir 3: kuvvet / kok / sabitler
      [
        CalcButton(
          label: second ? '∛' : '√',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert(second ? 'cbrt(' : 'sqrt(', InsertKind.openFunc),
        ),
        CalcButton(
          label: second ? 'x³' : 'x²',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert(second ? '^3' : '^2', InsertKind.postfix),
        ),
        CalcButton(
          label: second ? '10ˣ' : 'xʸ',
          styleType: CalcButtonStyleType.function,
          onTap: () => second
              ? c.insert('10^(', InsertKind.openFunc)
              : c.insert('^', InsertKind.operator),
        ),
        CalcButton(
          label: second ? 'eˣ' : 'e',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert(second ? 'exp(' : 'e', InsertKind.constant),
        ),
        CalcButton(
          label: 'π',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert('π', InsertKind.constant),
        ),
      ],
      // Satir 4: parantez / yuzde / faktoriyel / temizle
      [
        CalcButton(
          label: '( )',
          styleType: CalcButtonStyleType.function,
          onTap: c.smartParenthesis,
        ),
        CalcButton(
          label: '%',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert('%', InsertKind.postfix),
        ),
        CalcButton(
          label: 'n!',
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert('!', InsertKind.postfix),
        ),
        CalcButton(
          label: 'AC',
          styleType: CalcButtonStyleType.danger,
          onTap: c.clearAll,
        ),
        CalcButton(
          label: '⌫',
          styleType: CalcButtonStyleType.danger,
          icon: Icons.backspace_outlined,
          onTap: c.backspace,
          onLongPress: c.clearAll,
        ),
      ],
      // Satir 5-8: sayilar ve islemler
      [
        CalcButton(label: '7', onTap: () => c.insert('7', InsertKind.digit)),
        CalcButton(label: '8', onTap: () => c.insert('8', InsertKind.digit)),
        CalcButton(label: '9', onTap: () => c.insert('9', InsertKind.digit)),
        CalcButton(
          label: '÷',
          styleType: CalcButtonStyleType.operator,
          onTap: () => c.insert('÷', InsertKind.operator),
        ),
        CalcButton(
          label: '×',
          styleType: CalcButtonStyleType.operator,
          onTap: () => c.insert('×', InsertKind.operator),
        ),
      ],
      [
        CalcButton(label: '4', onTap: () => c.insert('4', InsertKind.digit)),
        CalcButton(label: '5', onTap: () => c.insert('5', InsertKind.digit)),
        CalcButton(label: '6', onTap: () => c.insert('6', InsertKind.digit)),
        CalcButton(
          label: '−',
          styleType: CalcButtonStyleType.operator,
          onTap: () => c.insert('-', InsertKind.operator),
        ),
        CalcButton(
          label: '+',
          styleType: CalcButtonStyleType.operator,
          onTap: () => c.insert('+', InsertKind.operator),
        ),
      ],
      [
        CalcButton(label: '1', onTap: () => c.insert('1', InsertKind.digit)),
        CalcButton(label: '2', onTap: () => c.insert('2', InsertKind.digit)),
        CalcButton(label: '3', onTap: () => c.insert('3', InsertKind.digit)),
        CalcButton(label: '+/−', fontSize: 17, onTap: c.toggleSign),
        CalcButton(
          label: '=',
          styleType: CalcButtonStyleType.accent,
          onTap: c.equals,
        ),
      ],
      [
        CalcButton(label: '0', onTap: () => c.insert('0', InsertKind.digit)),
        CalcButton(label: '.', onTap: () => c.insert('.', InsertKind.digit)),
        CalcButton(
          label: 'E',
          fontSize: 17,
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert('E', InsertKind.digit),
        ),
        CalcButton(
          label: 'mod',
          fontSize: 15,
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert('mod', InsertKind.operator),
        ),
        CalcButton(
          label: 'log₂',
          fontSize: 15,
          styleType: CalcButtonStyleType.function,
          onTap: () => c.insert('log2(', InsertKind.openFunc),
        ),
      ],
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
      child: Column(
        children: [
          for (var r = 0; r < rows.length; r++)
            Expanded(
              flex: r < 4 ? 8 : 10,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: [
                    for (var i = 0; i < rows[r].length; i++) ...[
                      Expanded(child: rows[r][i]),
                      if (i != rows[r].length - 1) const SizedBox(width: 6),
                    ],
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_theme.dart';
import '../state/calculator_controller.dart';

/// Ust ekran: durum satiri, ifade ve canli sonuc.
class DisplayPanel extends StatelessWidget {
  const DisplayPanel({super.key, required this.controller, required this.onHistoryTap});

  final CalculatorController controller;
  final VoidCallback onHistoryTap;

  @override
  Widget build(BuildContext context) {
    final expression = controller.expression;
    final preview = controller.preview;
    final error = controller.error;
    final done = controller.justEvaluated;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: const BoxDecoration(
        color: AppColors.background,
        border: Border(bottom: BorderSide(color: AppColors.surface, width: 1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _StatusBar(controller: controller, onHistoryTap: onHistoryTap),
          const SizedBox(height: 14),
          // Ifade satiri (saga hizali, yatay kaydirilabilir)
          SizedBox(
            height: 46,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              reverse: true,
              physics: const ClampingScrollPhysics(),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  expression.isEmpty ? '0' : expression,
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: done ? 26 : 34,
                    fontWeight: FontWeight.w500,
                    color: expression.isEmpty
                        ? AppColors.muted
                        : (done ? AppColors.muted : AppColors.foreground),
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          // Sonuc / hata satiri
          SizedBox(
            height: 44,
            child: Align(
              alignment: Alignment.centerRight,
              child: error != null
                  ? Text(
                      error,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: AppColors.danger,
                      ),
                    )
                  : GestureDetector(
                      onLongPress: preview.isEmpty
                          ? null
                          : () {
                              Clipboard.setData(ClipboardData(text: preview));
                              HapticFeedback.mediumImpact();
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Sonuc kopyalandi'),
                                  duration: Duration(milliseconds: 900),
                                  behavior: SnackBarBehavior.floating,
                                ),
                              );
                            },
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        reverse: true,
                        child: Text(
                          preview.isEmpty ? '' : (done ? preview : '= $preview'),
                          maxLines: 1,
                          style: TextStyle(
                            fontSize: done ? 40 : 24,
                            fontWeight: FontWeight.w700,
                            color: done ? AppColors.accent : AppColors.muted,
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusBar extends StatelessWidget {
  const _StatusBar({required this.controller, required this.onHistoryTap});

  final CalculatorController controller;
  final VoidCallback onHistoryTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _Chip(
          label: controller.angleLabel,
          active: true,
          onTap: controller.toggleAngleMode,
        ),
        const SizedBox(width: 8),
        _Chip(
          label: '2nd',
          active: controller.second,
          onTap: controller.toggleSecond,
        ),
        if (controller.hasMemory) ...[
          const SizedBox(width: 8),
          _Chip(
            label: 'M ${controller.memoryLabel}',
            active: false,
            onTap: controller.memoryRecall,
          ),
        ],
        const Spacer(),
        IconButton(
          onPressed: onHistoryTap,
          visualDensity: VisualDensity.compact,
          icon: const Icon(Icons.history, color: AppColors.muted, size: 22),
          tooltip: 'Gecmis',
        ),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.label, required this.active, required this.onTap});

  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: active ? AppColors.accent.withValues(alpha: 0.14) : AppColors.surface,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: active ? AppColors.accent : Colors.transparent,
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.4,
            color: active ? AppColors.accent : AppColors.muted,
          ),
        ),
      ),
    );
  }
}

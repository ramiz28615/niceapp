import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_theme.dart';

enum CalcButtonStyleType { number, function, operator, accent, danger }

/// Tek bir hesap makinesi tusu. Dokunma geri bildirimi ve
/// olcek animasyonu ile hizli hissettirir.
class CalcButton extends StatefulWidget {
  const CalcButton({
    super.key,
    required this.label,
    required this.onTap,
    this.onLongPress,
    this.styleType = CalcButtonStyleType.number,
    this.subLabel,
    this.fontSize,
    this.icon,
    this.active = false,
  });

  final String label;
  final String? subLabel;
  final IconData? icon;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final CalcButtonStyleType styleType;
  final double? fontSize;
  final bool active;

  @override
  State<CalcButton> createState() => _CalcButtonState();
}

class _CalcButtonState extends State<CalcButton> {
  bool _pressed = false;

  Color get _bg {
    switch (widget.styleType) {
      case CalcButtonStyleType.number:
        return AppColors.surfaceAlt;
      case CalcButtonStyleType.function:
        return AppColors.surface;
      case CalcButtonStyleType.operator:
        return AppColors.surfaceAlt;
      case CalcButtonStyleType.accent:
        return AppColors.accent;
      case CalcButtonStyleType.danger:
        return AppColors.surface;
    }
  }

  Color get _fg {
    switch (widget.styleType) {
      case CalcButtonStyleType.number:
        return AppColors.foreground;
      case CalcButtonStyleType.function:
        return AppColors.muted;
      case CalcButtonStyleType.operator:
        return AppColors.accent;
      case CalcButtonStyleType.accent:
        return AppColors.background;
      case CalcButtonStyleType.danger:
        return AppColors.danger;
    }
  }

  void _handleTap() {
    HapticFeedback.selectionClick();
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    final borderColor = widget.active ? AppColors.accent : Colors.transparent;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: _handleTap,
      onLongPress: widget.onLongPress == null
          ? null
          : () {
              HapticFeedback.mediumImpact();
              widget.onLongPress!.call();
            },
      child: AnimatedScale(
        scale: _pressed ? 0.94 : 1.0,
        duration: const Duration(milliseconds: 70),
        curve: Curves.easeOut,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          decoration: BoxDecoration(
            color: _pressed ? Color.lerp(_bg, AppColors.foreground, 0.12) : _bg,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: borderColor, width: 1.4),
          ),
          alignment: Alignment.center,
          child: widget.icon != null
              ? Icon(widget.icon, color: _fg, size: 22)
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      widget.label,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: widget.active ? AppColors.accent : _fg,
                        fontSize: widget.fontSize ??
                            (widget.styleType == CalcButtonStyleType.function ? 15 : 21),
                        fontWeight: FontWeight.w600,
                        height: 1.1,
                      ),
                    ),
                    if (widget.subLabel != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(
                          widget.subLabel!,
                          style: const TextStyle(
                            color: AppColors.muted,
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                  ],
                ),
        ),
      ),
    );
  }
}

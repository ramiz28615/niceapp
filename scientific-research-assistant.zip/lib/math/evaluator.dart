import 'dart:math' as math;

/// Aci modu: derece veya radyan.
enum AngleMode { deg, rad }

/// Hesaplama sirasinda olusan hatalar.
class EvalException implements Exception {
  const EvalException(this.message);
  final String message;

  @override
  String toString() => message;
}

enum _TokType { number, op, func, lparen, rparen }

class _Tok {
  const _Tok(this.type, this.text, {this.value = 0});
  final _TokType type;
  final String text;
  final double value;
}

/// Operator tanimi: oncelik, sag-birlesme, arity.
class _OpDef {
  const _OpDef(this.precedence, this.rightAssoc, this.arity);
  final int precedence;
  final bool rightAssoc;
  final int arity;
}

/// Shunting-yard tabanli, bagimsiz (paketsiz) bilimsel ifade yorumlayici.
///
/// Destekler:
///  - Dort islem: + - x /  (x, *, X, ÷, /, −)
///  - Kuvvet: ^  (sag birlesmeli)
///  - Faktoriyel: !  (son ek)
///  - Yuzde: %  (son ek, /100)
///  - Tekli eksi/arti
///  - Kapali carpim: 2(3+1), 2π, 3sin(x)
///  - Fonksiyonlar: sin cos tan asin acos atan sinh cosh tanh
///                  ln log log2 sqrt cbrt abs exp
///  - Sabitler: π (pi), e
class Evaluator {
  Evaluator._();

  static const Map<String, _OpDef> _ops = {
    '+': _OpDef(2, false, 2),
    '-': _OpDef(2, false, 2),
    '*': _OpDef(3, false, 2),
    '/': _OpDef(3, false, 2),
    'mod': _OpDef(3, false, 2),
    'u-': _OpDef(3, true, 1),
    'u+': _OpDef(3, true, 1),
    '^': _OpDef(4, true, 2),
  };

  static const Set<String> _funcs = {
    'sin', 'cos', 'tan',
    'asin', 'acos', 'atan',
    'sinh', 'cosh', 'tanh',
    'ln', 'log', 'log2',
    'sqrt', 'cbrt', 'abs', 'exp',
  };

  /// Ifadeyi hesaplar. Hata durumunda [EvalException] atar.
  static double evaluate(String raw, {AngleMode mode = AngleMode.rad}) {
    final tokens = _tokenize(_normalize(raw));
    if (tokens.isEmpty) throw const EvalException('Bos ifade');
    final rpn = _toRpn(tokens);
    return _evalRpn(rpn, mode);
  }

  /// Gorsel sembolleri hesaplanabilir sembollere cevirir.
  static String _normalize(String input) {
    return input
        .replaceAll('×', '*')
        .replaceAll('·', '*')
        .replaceAll('÷', '/')
        .replaceAll('−', '-')
        .replaceAll('–', '-')
        .replaceAll(',', '.')
        .replaceAll('√', 'sqrt')
        .replaceAll('∛', 'cbrt')
        .replaceAll('π', 'p1')
        .replaceAll(' ', '');
  }

  static List<_Tok> _tokenize(String s) {
    final out = <_Tok>[];
    var i = 0;
    // Bir sonraki token operand mi bekleniyor? (tekli operator tespiti icin)
    var expectOperand = true;

    void pushImplicitMultiply() {
      if (!expectOperand) out.add(const _Tok(_TokType.op, '*'));
    }

    while (i < s.length) {
      final c = s[i];

      // Sayi
      if (_isDigit(c) || c == '.') {
        final start = i;
        var seenDot = false;
        while (i < s.length && (_isDigit(s[i]) || (s[i] == '.' && !seenDot))) {
          if (s[i] == '.') seenDot = true;
          i++;
        }
        // Bilimsel gosterim: 1.2E5 / 1.2E-5
        if (i < s.length && (s[i] == 'E')) {
          final save = i;
          i++;
          if (i < s.length && (s[i] == '-' || s[i] == '+')) i++;
          if (i < s.length && _isDigit(s[i])) {
            while (i < s.length && _isDigit(s[i])) {
              i++;
            }
          } else {
            i = save;
          }
        }
        final text = s.substring(start, i);
        final value = double.tryParse(text);
        if (value == null) throw EvalException('Gecersiz sayi: $text');
        pushImplicitMultiply();
        out.add(_Tok(_TokType.number, text, value: value));
        expectOperand = false;
        continue;
      }

      // Pi sabiti (normalize sonrasi "p1")
      if (c == 'p' && i + 1 < s.length && s[i + 1] == '1') {
        pushImplicitMultiply();
        out.add(const _Tok(_TokType.number, 'π', value: math.pi));
        expectOperand = false;
        i += 2;
        continue;
      }

      // Harf ile baslayan: fonksiyon, sabit veya mod
      if (_isAlpha(c)) {
        final start = i;
        while (i < s.length && _isAlpha(s[i]) || (i < s.length && s[i] == '2' && i > start)) {
          i++;
        }
        final name = s.substring(start, i);
        if (name.isEmpty) throw EvalException('Gecersiz karakter: $c');

        if (_funcs.contains(name)) {
          pushImplicitMultiply();
          out.add(_Tok(_TokType.func, name));
          expectOperand = true;
          continue;
        }
        if (name == 'mod') {
          out.add(const _Tok(_TokType.op, 'mod'));
          expectOperand = true;
          continue;
        }
        if (name == 'e') {
          pushImplicitMultiply();
          out.add(const _Tok(_TokType.number, 'e', value: math.e));
          expectOperand = false;
          continue;
        }
        if (name == 'pi') {
          pushImplicitMultiply();
          out.add(const _Tok(_TokType.number, 'π', value: math.pi));
          expectOperand = false;
          continue;
        }
        // "e" ile baslayan bilesikler icin geri adim (ornek: e^2 -> e, ^, 2)
        if (name.startsWith('e')) {
          pushImplicitMultiply();
          out.add(const _Tok(_TokType.number, 'e', value: math.e));
          expectOperand = false;
          i = start + 1;
          continue;
        }
        throw EvalException('Bilinmeyen fonksiyon: $name');
      }

      // Parantezler
      if (c == '(') {
        pushImplicitMultiply();
        out.add(const _Tok(_TokType.lparen, '('));
        expectOperand = true;
        i++;
        continue;
      }
      if (c == ')') {
        out.add(const _Tok(_TokType.rparen, ')'));
        expectOperand = false;
        i++;
        continue;
      }

      // Son ek operatorler
      if (c == '!') {
        if (expectOperand) throw const EvalException('! icin operand yok');
        out.add(const _Tok(_TokType.op, 'fact'));
        expectOperand = false;
        i++;
        continue;
      }
      if (c == '%') {
        if (expectOperand) throw const EvalException('% icin operand yok');
        out.add(const _Tok(_TokType.op, 'pct'));
        expectOperand = false;
        i++;
        continue;
      }

      // Ikili / tekli operatorler
      if (c == '+' || c == '-') {
        out.add(_Tok(_TokType.op, expectOperand ? (c == '-' ? 'u-' : 'u+') : c));
        expectOperand = true;
        i++;
        continue;
      }
      if (c == '*' || c == '/' || c == '^') {
        if (expectOperand) throw EvalException('Beklenmeyen operator: $c');
        out.add(_Tok(_TokType.op, c));
        expectOperand = true;
        i++;
        continue;
      }

      throw EvalException('Gecersiz karakter: $c');
    }

    return out;
  }

  static List<_Tok> _toRpn(List<_Tok> tokens) {
    final output = <_Tok>[];
    final stack = <_Tok>[];

    for (final t in tokens) {
      switch (t.type) {
        case _TokType.number:
          output.add(t);
        case _TokType.func:
          stack.add(t);
        case _TokType.lparen:
          stack.add(t);
        case _TokType.rparen:
          var matched = false;
          while (stack.isNotEmpty) {
            final top = stack.removeLast();
            if (top.type == _TokType.lparen) {
              matched = true;
              break;
            }
            output.add(top);
          }
          if (!matched) throw const EvalException('Parantez hatasi');
          if (stack.isNotEmpty && stack.last.type == _TokType.func) {
            output.add(stack.removeLast());
          }
        case _TokType.op:
          // Son ek operatorler dogrudan cikisa gider.
          if (t.text == 'fact' || t.text == 'pct') {
            output.add(t);
            break;
          }
          // On ek (tekli) operatorler dogrudan yigina girer.
          if (t.text == 'u-' || t.text == 'u+') {
            stack.add(t);
            break;
          }
          final def = _ops[t.text]!;
          while (stack.isNotEmpty && stack.last.type == _TokType.op) {
            final topDef = _ops[stack.last.text]!;
            final shouldPop = def.rightAssoc
                ? topDef.precedence > def.precedence
                : topDef.precedence >= def.precedence;
            if (!shouldPop) break;
            output.add(stack.removeLast());
          }
          stack.add(t);
      }
    }

    while (stack.isNotEmpty) {
      final top = stack.removeLast();
      if (top.type == _TokType.lparen) throw const EvalException('Parantez hatasi');
      output.add(top);
    }
    return output;
  }

  static double _evalRpn(List<_Tok> rpn, AngleMode mode) {
    final st = <double>[];

    double pop() {
      if (st.isEmpty) throw const EvalException('Eksik ifade');
      return st.removeLast();
    }

    for (final t in rpn) {
      switch (t.type) {
        case _TokType.number:
          st.add(t.value);
        case _TokType.func:
          st.add(_applyFunc(t.text, pop(), mode));
        case _TokType.op:
          switch (t.text) {
            case 'fact':
              st.add(_factorial(pop()));
            case 'pct':
              st.add(pop() / 100.0);
            case 'u-':
              st.add(-pop());
            case 'u+':
              st.add(pop());
            case '+':
              final b = pop();
              st.add(pop() + b);
            case '-':
              final b = pop();
              st.add(pop() - b);
            case '*':
              final b = pop();
              st.add(pop() * b);
            case '/':
              final b = pop();
              final a = pop();
              if (b == 0) throw const EvalException('Sifira bolme');
              st.add(a / b);
            case 'mod':
              final b = pop();
              final a = pop();
              if (b == 0) throw const EvalException('Sifira bolme');
              st.add(a % b);
            case '^':
              final b = pop();
              st.add(math.pow(pop(), b).toDouble());
            default:
              throw EvalException('Bilinmeyen operator: ${t.text}');
          }
        case _TokType.lparen:
        case _TokType.rparen:
          throw const EvalException('Parantez hatasi');
      }
    }

    if (st.length != 1) throw const EvalException('Eksik ifade');
    final result = st.single;
    if (result.isNaN) throw const EvalException('Tanimsiz sonuc');
    if (result.isInfinite) throw const EvalException('Sonuc cok buyuk');
    return result;
  }

  static double _applyFunc(String name, double x, AngleMode mode) {
    final toRad = mode == AngleMode.deg ? math.pi / 180.0 : 1.0;
    final fromRad = mode == AngleMode.deg ? 180.0 / math.pi : 1.0;

    switch (name) {
      case 'sin':
        return _clean(math.sin(x * toRad));
      case 'cos':
        return _clean(math.cos(x * toRad));
      case 'tan':
        final c = math.cos(x * toRad);
        if (c.abs() < 1e-15) throw const EvalException('tan tanimsiz');
        return _clean(math.sin(x * toRad) / c);
      case 'asin':
        if (x < -1 || x > 1) throw const EvalException('asin tanim disi');
        return math.asin(x) * fromRad;
      case 'acos':
        if (x < -1 || x > 1) throw const EvalException('acos tanim disi');
        return math.acos(x) * fromRad;
      case 'atan':
        return math.atan(x) * fromRad;
      case 'sinh':
        return (math.exp(x) - math.exp(-x)) / 2;
      case 'cosh':
        return (math.exp(x) + math.exp(-x)) / 2;
      case 'tanh':
        final e2 = math.exp(2 * x);
        return (e2 - 1) / (e2 + 1);
      case 'ln':
        if (x <= 0) throw const EvalException('ln tanim disi');
        return math.log(x);
      case 'log':
        if (x <= 0) throw const EvalException('log tanim disi');
        return math.log(x) / math.ln10;
      case 'log2':
        if (x <= 0) throw const EvalException('log2 tanim disi');
        return math.log(x) / math.ln2;
      case 'sqrt':
        if (x < 0) throw const EvalException('Negatif karekok');
        return math.sqrt(x);
      case 'cbrt':
        return x < 0 ? -math.pow(-x, 1 / 3).toDouble() : math.pow(x, 1 / 3).toDouble();
      case 'abs':
        return x.abs();
      case 'exp':
        return math.exp(x);
      default:
        throw EvalException('Bilinmeyen fonksiyon: $name');
    }
  }

  static double _factorial(double x) {
    if (x < 0) throw const EvalException('Negatif faktoriyel');
    if (x != x.roundToDouble()) throw const EvalException('Tam sayi olmali');
    if (x > 170) throw const EvalException('Faktoriyel cok buyuk');
    var acc = 1.0;
    for (var i = 2; i <= x.toInt(); i++) {
      acc *= i;
    }
    return acc;
  }

  /// 1e-16 gibi kayan nokta artiklarini temizler (sin(180) -> 0).
  static double _clean(double v) => v.abs() < 1e-12 ? 0.0 : v;

  static bool _isDigit(String c) => c.codeUnitAt(0) >= 48 && c.codeUnitAt(0) <= 57;

  static bool _isAlpha(String c) {
    final u = c.codeUnitAt(0);
    return (u >= 97 && u <= 122) || (u >= 65 && u <= 90);
  }
}

/// Sonuclari okunabilir sekilde bicimlendirir.
class NumberFormatter {
  NumberFormatter._();

  /// 12 anlamli basamak, gereksiz sifirlar temizlenir,
  /// cok buyuk/kucuk sayilar bilimsel gosterime gecer.
  static String format(double value, {bool group = true}) {
    if (value == 0) return '0';
    if (value.isNaN) return 'Tanimsiz';
    if (value.isInfinite) return value.isNegative ? '-∞' : '∞';

    final abs = value.abs();
    if (abs >= 1e12 || abs < 1e-9) {
      final parts = value.toStringAsExponential(8).split('e');
      final mantissa = _stripZeros(parts[0]);
      final exp = int.parse(parts[1]);
      return '${mantissa}E$exp';
    }

    var text = value.toStringAsFixed(10);
    text = _stripZeros(text);

    // Kayan nokta artiklarini yuvarla (0.30000000000000004 gibi)
    final reparsed = double.tryParse(text);
    if (reparsed != null) {
      final compact = _stripZeros(reparsed.toStringAsPrecision(12));
      if (double.tryParse(compact) == reparsed) text = compact;
    }

    if (!group) return text;
    return _group(text);
  }

  static String _stripZeros(String s) {
    if (!s.contains('.')) return s;
    var out = s.replaceFirst(RegExp(r'0+$'), '');
    if (out.endsWith('.')) out = out.substring(0, out.length - 1);
    return out.isEmpty ? '0' : out;
  }

  /// Binlik ayirici olarak ince bosluk yerine nokta yerine bosluk kullanir.
  static String _group(String text) {
    final negative = text.startsWith('-');
    final body = negative ? text.substring(1) : text;
    final dot = body.indexOf('.');
    final intPart = dot == -1 ? body : body.substring(0, dot);
    final rest = dot == -1 ? '' : body.substring(dot);

    final buf = StringBuffer();
    for (var i = 0; i < intPart.length; i++) {
      if (i > 0 && (intPart.length - i) % 3 == 0) buf.write(' ');
      buf.write(intPart[i]);
    }
    return '${negative ? '-' : ''}$buf$rest';
  }
}

/// Gecmis kaydi: ifade, sonuc, aci modu ve zaman.
class HistoryEntry {
  const HistoryEntry({
    required this.expression,
    required this.result,
    required this.angleMode,
    required this.createdAt,
  });

  final String expression;
  final String result;
  final String angleMode; // 'DEG' | 'RAD'
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'e': expression,
        'r': result,
        'a': angleMode,
        't': createdAt.millisecondsSinceEpoch,
      };

  static HistoryEntry fromJson(Map<String, dynamic> json) => HistoryEntry(
        expression: json['e'] as String? ?? '',
        result: json['r'] as String? ?? '',
        angleMode: json['a'] as String? ?? 'RAD',
        createdAt: DateTime.fromMillisecondsSinceEpoch(
          (json['t'] as num?)?.toInt() ?? 0,
        ),
      );
}

import 'package:flutter/material.dart';

/// Uygulama renk paleti: 1 vurgu + 3 notr + 1 ikincil vurgu.
class AppColors {
  AppColors._();

  static const Color background = Color(0xFF0B0F14); // koyu zemin
  static const Color surface = Color(0xFF151B23); // panel / tus
  static const Color surfaceAlt = Color(0xFF1E2732); // ikincil tus
  static const Color foreground = Color(0xFFE6EDF3); // metin
  static const Color muted = Color(0xFF8A97A6); // ikincil metin
  static const Color accent = Color(0xFF2DD4A7); // ana vurgu (=, sonuc)
  static const Color danger = Color(0xFFFF7A59); // silme / hata
}

class AppTheme {
  AppTheme._();

  static ThemeData dark() {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: const ColorScheme.dark(
        surface: AppColors.background,
        primary: AppColors.accent,
        onPrimary: AppColors.background,
        secondary: AppColors.danger,
        onSurface: AppColors.foreground,
        error: AppColors.danger,
      ),
      splashFactory: InkSparkle.splashFactory,
      textTheme: base.textTheme.apply(
        bodyColor: AppColors.foreground,
        displayColor: AppColors.foreground,
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.surface,
        surfaceTintColor: Colors.transparent,
      ),
    );
  }
}

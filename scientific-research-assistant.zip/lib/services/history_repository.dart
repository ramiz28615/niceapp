import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/history_entry.dart';

/// Gecmisi cihazda kalici olarak saklar (SharedPreferences).
/// Yazma islemleri asenkron ve tembeldir; UI beklemez.
class HistoryRepository {
  HistoryRepository();

  static const String _key = 'history_v1';
  static const int maxItems = 300;

  SharedPreferences? _prefs;
  List<HistoryEntry> _cache = <HistoryEntry>[];

  List<HistoryEntry> get items => List.unmodifiable(_cache);

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs?.getString(_key);
    if (raw == null || raw.isEmpty) return;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        _cache = decoded
            .whereType<Map<String, dynamic>>()
            .map(HistoryEntry.fromJson)
            .toList(growable: true);
      }
    } catch (_) {
      _cache = <HistoryEntry>[];
    }
  }

  Future<void> add(HistoryEntry entry) async {
    _cache.insert(0, entry);
    if (_cache.length > maxItems) {
      _cache = _cache.sublist(0, maxItems);
    }
    await _persist();
  }

  Future<void> removeAt(int index) async {
    if (index < 0 || index >= _cache.length) return;
    _cache.removeAt(index);
    await _persist();
  }

  Future<void> clear() async {
    _cache = <HistoryEntry>[];
    await _persist();
  }

  Future<void> _persist() async {
    _prefs ??= await SharedPreferences.getInstance();
    final raw = jsonEncode(_cache.map((e) => e.toJson()).toList());
    await _prefs!.setString(_key, raw);
  }
}

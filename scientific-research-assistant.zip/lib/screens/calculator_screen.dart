import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_theme.dart';
import '../state/calculator_controller.dart';
import '../widgets/display_panel.dart';
import '../widgets/history_sheet.dart';
import '../widgets/keypad.dart';

/// Ana ekran: ust kisim ekran, alt kisim tus takimi.
/// Yukari kaydirma veya saga kaydirma ile gecmis acilir.
class CalculatorScreen extends StatelessWidget {
  const CalculatorScreen({super.key, required this.controller});

  final CalculatorController controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListenableBuilder(
          listenable: controller,
          builder: (context, _) {
            return Column(
              children: [
                GestureDetector(
                  onVerticalDragEnd: (details) {
                    if ((details.primaryVelocity ?? 0) > 120) {
                      HapticFeedback.selectionClick();
                      HistorySheet.show(context, controller);
                    }
                  },
                  child: DisplayPanel(
                    controller: controller,
                    onHistoryTap: () => HistorySheet.show(context, controller),
                  ),
                ),
                const _RecentStrip(),
                Expanded(child: Keypad(controller: controller)),
              ],
            );
          },
        ),
      ),
    );
  }
}

/// Ekranin altinda son 3 islemi gosteren hizli erisim seridi.
class _RecentStrip extends StatelessWidget {
  const _RecentStrip();

  @override
  Widget build(BuildContext context) {
    final controller = CalculatorScope.of(context);
    final recents = controller.history.take(4).toList();
    if (recents.isEmpty) return const SizedBox(height: 4);

    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        itemCount: recents.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final entry = recents[index];
          return GestureDetector(
            onTap: () {
              HapticFeedback.selectionClick();
              controller.useHistory(entry, useResult: true);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                entry.result,
                style: const TextStyle(
                  fontSize: 13,
                  color: AppColors.muted,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Controller'i agac boyunca tasiyan basit kapsam.
class CalculatorScope extends InheritedNotifier<CalculatorController> {
  const CalculatorScope({
    super.key,
    required CalculatorController controller,
    required super.child,
  }) : super(notifier: controller);

  static CalculatorController of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<CalculatorScope>();
    assert(scope != null, 'CalculatorScope bulunamadi');
    return scope!.notifier!;
  }
}

import 'package:flutter/foundation.dart';

import '../math/evaluator.dart';
import '../math/formatter.dart';
import '../models/history_entry.dart';
import '../services/history_repository.dart';

/// Tus tiplerine gore giris davranisini belirler.
enum InsertKind {
  digit, // 0-9 ve .
  operator, // + - × ÷ ^
  openFunc, // sin( , √( , ln( ...
  constant, // π , e
  postfix, // ! , %
  paren, // ( , )
}

/// Hesap makinesinin tum durumu. UI sadece dinler.
class CalculatorController extends ChangeNotifier {
  CalculatorController(this._history);

  final HistoryRepository _history;

  String _expression = '';
  String _preview = '';
  String? _error;
  bool _justEvaluated = false;
  bool _second = false;
  AngleMode _angleMode = AngleMode.deg;
  double _memory = 0;
  String _lastAnswer = '0';

  String get expression => _expression;
  String get preview => _preview;
  String? get error => _error;
  bool get second => _second;
  bool get isDeg => _angleMode == AngleMode.deg;
  String get angleLabel => _angleMode == AngleMode.deg ? 'DEG' : 'RAD';
  bool get hasMemory => _memory != 0;
  String get memoryLabel => NumberFormatter.format(_memory);
  bool get justEvaluated => _justEvaluated;
  List<HistoryEntry> get history => _history.items;

  Future<void> load() async {
    await _history.init();
    if (_history.items.isNotEmpty) {
      _lastAnswer = _history.items.first.result.replaceAll(' ', '');
    }
    notifyListeners();
  }

  // ---------------------------------------------------------------- giris

  void insert(String token, InsertKind kind) {
    if (_justEvaluated) {
      // Sonuctan sonra: islem tusuna basilirsa sonuc uzerinden devam et,
      // sayi/fonksiyon tusuna basilirsa sifirdan basla.
      if (kind == InsertKind.operator || kind == InsertKind.postfix) {
        _expression = _lastAnswer;
      } else {
        _expression = '';
      }
      _justEvaluated = false;
    }

    if (kind == InsertKind.operator && _endsWithOperator()) {
      // Ust uste operator yazilmasin, son operatoru degistir.
      _expression = _expression.substring(0, _expression.length - 1) + token;
    } else if (kind == InsertKind.digit && token == '.' && _currentNumberHasDot()) {
      return;
    } else {
      _expression += token;
    }

    _recompute();
  }

  void backspace() {
    if (_justEvaluated) {
      _justEvaluated = false;
      _preview = '';
    }
    if (_expression.isEmpty) return;

    // "sin(" gibi coklu karakterli girisleri tek seferde sil.
    final match = RegExp(r'(asin|acos|atan|sinh|cosh|tanh|sin|cos|tan|log2|log|ln|sqrt|cbrt|abs|exp)\($')
        .firstMatch(_expression);
    if (match != null) {
      _expression = _expression.substring(0, match.start);
    } else {
      _expression = _expression.substring(0, _expression.length - 1);
    }
    _recompute();
  }

  void clearAll() {
    _expression = '';
    _preview = '';
    _error = null;
    _justEvaluated = false;
    notifyListeners();
  }

  void insertAnswer() {
    if (_justEvaluated) {
      _expression = '';
      _justEvaluated = false;
    }
    _expression += _lastAnswer;
    _recompute();
  }

  void toggleSign() {
    if (_expression.isEmpty || _justEvaluated) {
      _expression = _justEvaluated ? '-($_lastAnswer)' : '-';
      _justEvaluated = false;
    } else if (_expression.startsWith('-')) {
      _expression = _expression.substring(1);
    } else {
      _expression = '-$_expression';
    }
    _recompute();
  }

  void smartParenthesis() {
    final open = _expression.split('(').length - 1;
    final close = _expression.split(')').length - 1;
    final lastChar = _expression.isEmpty ? '' : _expression[_expression.length - 1];
    final needClose = open > close && !'+-×÷^('.contains(lastChar) && lastChar.isNotEmpty;
    insert(needClose ? ')' : '(', InsertKind.paren);
  }

  // ------------------------------------------------------------- ayarlar

  void toggleSecond() {
    _second = !_second;
    notifyListeners();
  }

  void toggleAngleMode() {
    _angleMode = _angleMode == AngleMode.deg ? AngleMode.rad : AngleMode.deg;
    _recompute();
  }

  // -------------------------------------------------------------- hafiza

  void memoryAdd() {
    final v = _currentValue();
    if (v != null) {
      _memory += v;
      notifyListeners();
    }
  }

  void memorySubtract() {
    final v = _currentValue();
    if (v != null) {
      _memory -= v;
      notifyListeners();
    }
  }

  void memoryRecall() {
    if (_memory == 0) return;
    if (_justEvaluated) {
      _expression = '';
      _justEvaluated = false;
    }
    _expression += NumberFormatter.format(_memory, group: false);
    _recompute();
  }

  void memoryClear() {
    _memory = 0;
    notifyListeners();
  }

  // ------------------------------------------------------------ hesapla

  Future<void> equals() async {
    if (_expression.trim().isEmpty) return;
    try {
      final value = Evaluator.evaluate(_expression, mode: _angleMode);
      final formatted = NumberFormatter.format(value);
      final entry = HistoryEntry(
        expression: _expression,
        result: formatted,
        angleMode: angleLabel,
        createdAt: DateTime.now(),
      );
      _lastAnswer = NumberFormatter.format(value, group: false);
      _preview = formatted;
      _error = null;
      _justEvaluated = true;
      notifyListeners();
      await _history.add(entry);
      notifyListeners();
    } on EvalException catch (e) {
      _error = e.message;
      _preview = '';
      notifyListeners();
    } catch (_) {
      _error = 'Hesaplanamadi';
      _preview = '';
      notifyListeners();
    }
  }

  // ------------------------------------------------------------- gecmis

  void useHistory(HistoryEntry entry, {bool useResult = false}) {
    _expression = (useResult ? entry.result : entry.expression).replaceAll(' ', '');
    _justEvaluated = false;
    _recompute();
  }

  Future<void> deleteHistoryAt(int index) async {
    await _history.removeAt(index);
    notifyListeners();
  }

  Future<void> clearHistory() async {
    await _history.clear();
    notifyListeners();
  }

  // ------------------------------------------------------------ yardimci

  /// Her tus basiminda canli on izleme hesaplar (hata varsa sessiz gecer).
  void _recompute() {
    _error = null;
    if (_expression.trim().isEmpty) {
      _preview = '';
      notifyListeners();
      return;
    }
    try {
      final value = Evaluator.evaluate(_expression, mode: _angleMode);
      _preview = NumberFormatter.format(value);
    } catch (_) {
      _preview = '';
    }
    notifyListeners();
  }

  double? _currentValue() {
    try {
      if (_expression.trim().isEmpty) return double.tryParse(_lastAnswer);
      return Evaluator.evaluate(_expression, mode: _angleMode);
    } catch (_) {
      return null;
    }
  }

  bool _endsWithOperator() {
    if (_expression.isEmpty) return false;
    return '+-×÷^'.contains(_expression[_expression.length - 1]);
  }

  bool _currentNumberHasDot() {
    for (var i = _expression.length - 1; i >= 0; i--) {
      final c = _expression[i];
      if (c == '.') return true;
      if (!RegExp(r'[0-9]').hasMatch(c)) return false;
    }
    return false;
  }
}
